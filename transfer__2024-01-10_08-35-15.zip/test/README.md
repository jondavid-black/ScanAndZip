# ScanAndZip
Simple python program to scan and package files for transfer.
